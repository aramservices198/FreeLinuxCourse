﻿# Marsruutimisprotokollid

## Tunni sisu

Oleks tõeline piin käsitsi seadistada kõik marsruudid kõikidel võrguseadmetel. Selle asemel kasutatakse marsruutimisprotokolle, mis aitavad võrgul toime tulla muudatustega. Protokoll õpib erinevate marsruutide kohta, lisab need marsruutimistabelisse ja ka suunab paketid vajalikus suunas. Marsruutimisprotokolle on peamiselt kaht tüüpi: kaugusvektori ja ühenduse oleku protokollid.

<b>Lõimumine</b>

Enne kui rääkida protokollidest tuleks tutvustada terminit, mida marsruutimises tuntakse lõimumisena. Kasutades marsruutimisprotokolle, suhtlevad marsruuterid üksteisega, et koguda ja jagada võrgu kohta informatsiooni. Kui nad lõpuks jõuavad ühisele arusaamale sellest kuidas võrk välja näeb, kaardistavad marsruutimistabelid kogu topoloogia, saavutades nõnda lõimumise. Kui võrgu topoloogiasse ilmub mingi takistus või muutus, katkeb lõimunud olek kuniks kõik marsruuterid on muutusest teadlikuks saanud.

## Harjutus

Harjutust pole.

## Küsimus

Millises seisundis on võrk kus kõik marsruuterid on teadlikud võrgu topoloogiast?

## Vastus

lõimunud
