# Mis asi on marsruuter?

## Tunni sisu

Seda sõna on siin peatükkides päris palju kasutatud. Loodetavasi see ei ole see midagi võõrast, eriti kuna väga tõenäoliselt on see lugejal kodus olemas. Marsruuter võimaldab arvutitel ühes ja samas aga ka erinevates võrkudes suhelda. Tüüpiliselt on marsruuteril kohtvõrgu liidesed, mis võimaldavad arvutitel kohtvõrgus ühenduda. Samuti on olemas Interneti port, mis on ühendatud Internetiga. Mõnikord on selle pordi nimi WAN (*Wide Area Network* - laivõrk), kuna sisuliselt ühendab see kohtvõrgu laiema võrguga. Kui teostada ükskõik millist võrguga seotud tegevust, peab see läbima marsruuteri. See seade otsustab, kuhu võrgupaketid lähevad ja millised tohivad sisse tulla ning vahendab pakkette mitmete võrkude vahel.

<b>Kuidas marsruuter töötab?</b>

Marsruutimisest võib mõelda kui kirjade kohalekandmisest. On olemas sihtkoha aadress. Kui kiri saata postkontorisse siis vaadatakse seal, et kiri läheb Tartusse ja see pannakse selles suunas teele. Kiri saadetakse siis õigesse linna kui otsitakse üles postiindeks, seejärel tänav ja seejärel õige maja. Lõpuks jõuab kiri saajani. Kui aga saata kirja sama linna piires on tööd palju vähem ja kirja ei pea nii mitu korda vahendama.

Kui marsruuditakse pakette, kasutatakse sarnaseid aadressi "marsruute". Selleks, et saada võrku A, saadame kirja võrku B. Kui selline teekond on tundmatu siis on olemas ka vaikimisi marsruut, mida paketid parema variandi puudumisel kasutavad.  Kõik marsruudid asuvad marsruutimise tabelis, mida süsteem kasutab võrgus orienteerumiseks.

<b>Hüpped</b>

Võrgus liiguvad paketid hüpetena. Teekonda alguspunktist lõppunkti võib mõõta ka hüpetes. Ütleme, et punktide A ja B vahel on kaks marsruuterit ja see tähendab ka, et nende punktide vahel on vaja teha kaks hüpet. Iga hüpe on vahendav seade, marsruuter, mida on vaja läbida.

## Harjutus

Harjutust pole.

## Küsimus

Kuidas paketid mõõdavad kaugusi?

## Vastus

hüpetes
