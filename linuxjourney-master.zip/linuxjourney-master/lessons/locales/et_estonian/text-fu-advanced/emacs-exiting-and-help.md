# Emacs: väljumine ja abi

## Tunni sisu

<b>Väljumiseks</b>

<pre>C-x C-c</pre>

Kui sel hetkel on avatud puhvreid, siis palutakse need enne väljumist salvestada.

<b>Oled segaduses?</b>

<pre>C-h C-h : help menu</pre>

<b>Võta tagasi</b>

<pre>C-x u</pre>

Nagu isegi näed on Emacs'il rohkem liikuvaid osi ja selle õppimine on alguses natuke raskem. Vastutasuks saad aga väga võimsa tekstiredaktori.

## Harjutus

Külasta Emacs'i veebilehte, et rohkem käske ära õppida. <a href="https://www.gnu.org/software/emacs/">Emacs</a>

## Küsimus

Kuidas pääseda ligi Abi menüüle?

## Vastus

C-h C-h
