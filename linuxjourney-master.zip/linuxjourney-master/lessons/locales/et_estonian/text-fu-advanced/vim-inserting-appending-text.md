# Vim ja teksti lisamine

## Tunni sisu

Võis märgata, et kui üritada teksti sisestada, siis see ei õnnestu. See on nii, kuna asutakse käsurežiimis. See võib muutuda päris keeruliseks, eriti kui tahta ainult avada faili ja teksti sisestada. Käsurežiimi kasutatakse käskude nagu h,j,k,l jne sisestamiseks. Selleks, et sisestada teksti, peab enne sisenema sisestusrežiimi

<ul>
<li>i - sisesta tekst kursori ette</li>
<li>O - sisesta tekst eelmisele reale</li>
<li>o - sisesta tekst järgmisele reale</li>
<li>a - lisa tekst kursori järele</li>
<li>A - lisa tekst rea lõppu</li>
</ul>

Kui siseneda ühte nendest sisestusrežiimidest siis näitab ka vim alumises servas, et ollakse sisestusrežiimis. Et väljuda sisestusrežiimist ja minna tagasi käsurežiimi, vajutada lihtsalt Esc klahvi.

## Harjutus

Mängi natuke režiimide vahetamisega.

## Küsimus

Millise klahviga saab sisestada teksti kursori ette.

## Vastus

i
