# Vim ja redigeerimine

## Tunni sisu

Nüüd kui oleme kirjutanud mõned read, redigeerime natuke ja eemaldame ebavajalikud osad.

<ul>
<li>x - kasutatakse, et eemaldada valitud tekst ning kustutada tähemärke.</li>
<li>dd - kasuta aktiivse rea kustutamiseks</li>
<li>y - kopeeri valitud osa</li>
<li>yy - kopeeri aktiivne rida</li>
<li>p - kleebi kopeeritud tekst kursori ette</li>
</ul>

## Harjutus

See peatükk tutvustas veidraid käske, ava oma tekstiredaktor ja proovi neid kasutada.

## Küsimus

Millise tähemärgiga kustutatakse terve rida?

## Vastus

dd
