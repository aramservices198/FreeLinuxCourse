# Tekstiredaktorid

## Tunni sisu

Kui õnnestub ühte ruumi kokku saada mõned tõsised linuxikasutajad ja küsida neilt, milline on parim tekstiredaktor siis võib kuulda lõputuid kiidusõnu kahele: vim ja emacs. Kui su elu sulle armas on, ära isegi ürita tõstatada graafilise redaktori kasutamise teemat.

Vim ja emacs on populaarsed tekstiredaktorid, mis on vaikimisi paigaldatud enamusele Linuxi distributsioonidest. Loomulikult on neil mõlemal omad head ja vead. Kui soovid ninja osavusega enda süsteemis ringi liikuda, siis pead kindlasti õppima ühte neist kasutama. Nad on loomu poolest koodikirjutamiseks ja tekstidokumentide töötlemiseks mõeldud ehk siis kõik-ühes redaktorid.

#Harjutus

Tutvu natuke nende redaktoritega:

<a href="http://www.vim.org/">Vim</a>
<a href="https://www.gnu.org/software/emacs/">emacs</a>

## Küsimus

Küsimust pole, mine julgelt edasi!

## Vastus


