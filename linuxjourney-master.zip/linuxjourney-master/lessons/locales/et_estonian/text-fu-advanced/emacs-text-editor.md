# Emacs

## Tunni sisu

Emacs on mõeldud kasutajatele, kes soovivad eriti võimsat tekstiredaktorit. Kogu koodi redigeerimine, failide haldamine jpm saab ära teha emacs'iga. See käivitub pisut aeglasemalt ja õppida on alguses natuke raskem kui vim'i, kuid kui soovid võimsat redaktorit, mis on äärmiselt laiendatav, siis on see just sinu jaoks. Kui ma ütlen laiendatav, siis ma mõtlen tõesti, et sa saad kirjutada emacs'ile skripte, et selle funktsionaalsust suurendada.

Et emacs'i käivitada, kasuta:

<pre>emacs</pre>

Sind peaks vaikimisi võtma vastu tervituspuhver. 

Emacsis asubki sinu tekst puhvrites. Seega, kui avad faili, hoitakse selle sisu puhvris. Sul võib olla üheaegselt avatud mitu puhvrit ning nende vahel saab hõlpsasti liikuda.

## Harjutus

Selles peatükis harjutust ei ole.

## Küsimus

Küsimusi pole, mine edasi!

## Vastus


