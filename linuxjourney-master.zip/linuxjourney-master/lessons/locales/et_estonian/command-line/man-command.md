# man

## Tunni sisu

Oh, kuidas ma vahel unistan, et mõnel nendest programmidest oleks kasutusjuhend, et saaks nende kohta informatsiooni järgi vaadata. Aga õnneks neil ongi! Asjakohaselt nimetatud *man* (manuaal) leheküljed. *Man* käsuga saab vaadata mõne käsu kohta käivat kasutusjuhiste lehekülge.

<pre>$ man ls</pre>

*Man* leheküljed on kasutusjuhendid, mis on vaikimisi Linuxi operatsioonisüsteemidesse sisse ehitatud. Sealt võib leida dokumentatsiooni käskude kohta või muid aspekte süsteemi kohta.

Katsetada mõne käsuga, et sellest rohkem teada saada.

## Harjutus

Kasuta *man*'i *ls* käsu peal.

## Küsimus

Kuidas saab näha käsu kasutusjuhendit?

## Vastus

man
