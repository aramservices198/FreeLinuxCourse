# exit

## Tunni sisu

Hästi tehtud - baasteadmised on läbitud! Me oleme seda kõike aga ainult kergelt puudutanud. Nüüd kui on õpitud roomama siis järgmisel kursusel hakatakse kõndima.

Hetkel võib aga endale õlale patsutada ja natuke puhata. Et kestast väljuda, kasuta käsku exit

<pre>$ exit</pre>

või logout

<pre>$ logout</pre>

või lihtsalt sulgeda terminali akna. Seda saab ka teha kiirklahviga CTRL+D. Näeme järgmisel kursusel!

## Harjutus

Välju kestprogrammi aknast ja vaata, mis juhtub. Hoolitse selle eest, et töö oleks seal lõpetatud.

## Küsimus

Kuidas saab kestprogrammist väljuda?

## Vastus

exit
