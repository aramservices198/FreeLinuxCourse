﻿# Ülevaade operatsioonisüsteemi tuumast

## Tunni sisu

Nüüdseks peaks olema juba päris selge, et tuum ongi operatsioonisüsteemi kõige kesksem osa. Siiani on räägitud operatsioonisüsteemi erinevatest osadest kuid mainimata on jäänud, kuidas kõik need osad koos töötavad. Linuxi operatsioonisüsteemi võib jagad piltikult kolmeks.

Kõige algsem tase on riistvara. Sinna kuulub protsessor (ehk CPU), muutmälu, kõvaketas, võrguliidesed jne. See on füüsiline kiht, mis tegeleb arvutis toimuva teostamisega.

Järgmine tase ongi tuum, mis haldab protsesse ja mälu, seadmetevahelist suhtlust, tegeleb süsteemikutsetega, seab üles failisüsteemi jne. Tuuma töö on suhelda riistvaraga ja hoolitseda kasutaja soovide järgi protsesside toimimise eest.

Kasutajale kõige tuttavam kiht ongi kasutaja ruum. Sinna kuulub kestprogramm, kasutaja programmid, graafika jne.

Sellel kursusel keskendutakse tuumale ja õpitakse tundma selle iseärasusi.

## Harjutus

Harjutust pole.

## Küsimus

Milline operatsioonisüsteemi tase haldab seadmeid?

## Vastus

tuum
