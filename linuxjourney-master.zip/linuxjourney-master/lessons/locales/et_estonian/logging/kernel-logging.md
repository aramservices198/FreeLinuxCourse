﻿# Tuuma logimine

## Tunni sisu

<b>/var/log/dmesg</b><br>
Alglaadimisel logib süsteem informatsiooni tuuma ringpuhvri kohta. See annab informatsiooni riistvara juhtprogrammide, tuuma enda ja selle oleku kohta alglaamisel ja veel muudki. Selle logifaili võib leida otsiteekonnast */var/log/dmesg* ning see lähtestatakse igal süsteemi käivitamisel. Kasutaja ei pruugi selles hetkel mingit kasu näha kuid kui kunagi peaks ilmnema probleeme alglaadmisel või mõni riistvara probleem siis on dmesg parim koht otsimiseks. Seda logi saab vaadata käsuga *dmesg*.

<b>/var/log/kern.log</b><br>
Teine logi millest uurida tuuma informatsiooni on */var/log/kern.log* fail. See logib tuuma informatsiooni ja sündmusi süsteemis. Samuti logitakse dmesg väljundid.

## Harjutus

Vaadata *dmesg* ja *kern* logisid. Milliseid erinevusi võib märgata?

## Küsimus

Millise käsuga saab kuvada tuuma alglaadmise teated?

## Vastus

*dmesg*
