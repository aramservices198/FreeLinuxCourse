﻿# Võrgukiht

## Tunni sisu

Võrgukiht määrab pakettide marsruutimise (võrgupakettide liikumistee määramine) lähtepunktist sihtpunktini. Õnneks meie näites liigub pakett sama võrgu piires kuid internet koosneb ju mitmetest võrkudest.  Väiksemaid võrke, mis moodustavad Interneti, nimetatakse alamvõrkudeks. Kõik alamvõrgud ühenduvad ühel või teisel moel üksteisega. See on ka põhjus miks me saame minna lehele www.google.com hoolimata sellest, et see asub omas võrgus. Süveneme sellesse alamvõrkude peatükis kuid praegu võiks jätta meelde võrgukihiga seonduvalt, et IP aadressid määravad reeglid kuidas andmed erinevates alamvõrkudes liiguvad.

Võrgukiht võtab Transpordikihilt vastu segmendi ja kapseldab selle IP paketti. Seejärel lisatakse saatja ja saaja IP aadressid paketi päisesse. Nüüdseks on paketil informatsioon selle kohta kust see tuleb ja kuhu see läheb. Nüüd saadetakse see edasi riistvara kihile.

## Harjutus

Harjutust pole.

## Küsimus

Kuidas nimetatakse väiksemaid võrke, millest Internet koosneb?

## Vastus

alamvõrgud
