﻿# OSI mudel

## Tunni sisu

Enne praktilisema võrguteemalise materjali juurde asumist tuleb üle käia mõned igavad asjad. OSI (*Open System Interconnection*) mudel on võrgunduse teoreetiline mudel. See mudel kirjeldab pakettide liikumist võrgus läbi seitsme kihi. Selle mudeli eripäradesse me süvenema ei hakka kuna enamus võrgunduse kursuseid keskendub TCP/IP mudelile. Kuid kindlasti peaks teadma, et selline teoreetiline mudel on olemas ja on mänginud olulist rolli TCP/IP mudeli kujunemisel, mida tänapäeval kasutatakse.

## Harjutus

Lugeda OSI mudeli kohta: <a target="_blank" href="https://en.wikipedia.org/wiki/OSI_model">https://en.wikipedia.org/wiki/OSI_model</a> ja lisaks eesti keeles <a target="_blank" href="https://et.wikipedia.org/wiki/TCP/IP_mudel">https://et.wikipedia.org/wiki/TCP/IP_mudel</a>

## Küsimus

Milline on teoreetiline võrgunduse mudel?

## Vastus

OSI
