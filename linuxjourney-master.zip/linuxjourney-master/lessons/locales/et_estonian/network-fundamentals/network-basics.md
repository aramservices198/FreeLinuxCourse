﻿# Algteadmised võrgust

## Tunni sisu

Vaadeldes tüüpilist kodust võrguühendust, võib märgata erinevaid komponente.

<ul>
<li>ISP - <i>Internet service provider</i> ehk internetiteenuse pakkuja on ettevõte, kellele klient maksab internetiühenduse eest.</li>
<li>Marsruuter - Võimaldab arvutitel internetti ühenduda. Enamik kaasaegseid marsruutereid võimaldad ühenduda nii võrgukaabliga kui ka juhtmevabalt .</li>
<li>WAN - <i>Wide Area Network</i> ehk laivõrk, on see osa võrgust, mis jääb kliendi marsruuterist välja interneti poole. </li>
<li>WLAN - <i>Wireless Local Area Network</i> ehk traadita kohtvõrk on võrk marsruuteri ja juhtmevaba seadme, näiteks sülearvuti vahel.</li>
<li>LAN - <i>Local Area Network</i> ehk kohtvõrk on võrk marsruuteri ja kaabliga ühendatud seademete, nagu lauaarvuti vahel .</li>
<li>Host - Võrgus olevaid arvuteid nimetatakse hostideks.</li>
</ul>

Võrgus edastatavaid andmeid ja informatsiooni nimetatakse pakettideks ning selle võrguteemalise sektsiooni lõpuks on detailideni selge kuidas paketid hostide vahel reisivad.

## Harjutus

Selles peatükis harjutust ei ole.

## Küsimus

Kuidas on levinum viis tähistada kohtvõrke?

## Vastus

LAN
