﻿# Tarkvarakomplekt
Tarkvarakomplekti ehk distributsiooni kohta saab lugeda täpsemalt https://viki.pingviin.org/Distributsioon

## Tunni sisu

Operatsioonisüsteem koosneb paljudes tarkvarapakettidest nagu veebilehitsejad, tekstiredaktorid, meediamängijad jpm. Pakettide paigaldamise ja haldamisega tegeleb paketihaldustarkvara, kuid mitte kõiki pakette ei paigaldata läbi selle. Pakette võib paigaldada ka lihtsalt lähtekoodist (selleni jõuame peagi). Sellegipoolest suurem osa ajast kasutatakse ikkagi paketihaldustarkvara. Levinumad paketitüübid on Debian (.deb) ja Red Hat (.rpm). Debiani tüüpi pakette kasutatakse distrbutsioonides nagu Debian, Ubuntu, LinuxMint jt. Red Hat omi aga Red Hat Enterprise Linux, Fedora, CentOS jt.

Mis üldse on paketid? Need on näiteks Chromium, GIMP jt aga tegelikkuses on need lihtsalt suur hulk kokku kompileeritud faile. Isikut või isikuid kes sellist tarkvara kirjutavad kutsutakse <b>tarkvaraarendajateks</b>. Nemad kompileerivad oma koodi ja kirjutavad juhised kuidas seda paigaldada. Need arendajad töötavad selle kallal, et luua uut ja uuendada juba eksisteerivat tarkvara. Kui tarkvara on maailmale jagamiseks valmis, saadetakse see paketihalduritele kes hoolitsevad selle eest, et tarkvara jõuaks lõppkasutajateni. Paketihaldurid hindavad, haldavad ja jagavad tarkvara pakettide kujul.

## Harjutus

Selles peatükis harjutust ei ole.

## Küsimus

Küsimusi pole, liigu aga edasi.

## Vastus


