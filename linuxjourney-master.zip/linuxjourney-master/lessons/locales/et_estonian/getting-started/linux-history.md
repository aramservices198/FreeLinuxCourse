﻿# Ajalugu

## Tunni sisu

Hei algaja! Sa oled siis otsustanud sukelduda sellesse imelisse Linuxi maailma? Parem kinnita turvavöö, kuna tee on pikk ja raske. Minu nimi on Pingviin Pete ja ma olen siin selleks, et sind eelseisval teekonnal abistada. Alustame natukese Linuxi taustalooga.

Selleks, et saada teada, kuidas Linux alguse sai, peame pöörduma tagasi 1969. aasta algusesse, kui Ken Thompson ja Dennis Richie Bell Laboratories'st lõid UNIX operatsioonisüsteemi, mis hiljem kirjutati C keeles ümber, et see oleks kasutatav erinevatel riistvaraplatvormidel. Lõpuks sai sellest laialt kasutatav operatsioonisüsteem.

Umbes aastakümme hiljem alustas Richard Stallman tööd GNU (GNU is Not UNIX) projektiga, Hurd nimelise GNU tuumaga, mida kahjuks kunagi ei saadud valmis. GNU Üldine Avalik Litsents (GPL) loodi samuti selle projekti tulemusena.

Tuum on operatsioonisüsteemi kõige olulisem osa. See võimaldab riistvaral tarkvaraga suhelda. Lisaks teeb ka väga palju muid asju, kuid sellesse süveneme rohkem teisel kursusel. Praegu tea lihtsalt, et tuum kontrollib põhimõtteliselt kõike, mis toimub sinu süsteemis.

Selle aja jooksul arendati teisigi UNIXilaadseid süsteeme nagu BSD, MINIX jt. Kuid üks asi on kõigil nendel UNIXilaadsetel süsteemidel on ühine: ühtse tuuma puudumine.

Kuid siis 1991. aastal alustas noor Linus Torvalds tööd millegi kallal, mida täna teame Linuxi tuumana.

## Harjutus

Täiendav lugemine:
<li><a href='https://et.wikipedia.org/wiki/GNU'>GNU</a></li>
<li><a href='https://et.wikipedia.org/wiki/Ken_Thompson'>Ken Thompson</a></li>
<li><a href='https://et.wikipedia.org/wiki/Richard_Stallman'>Richard Stallman</a></li>
<li><a href='https://et.wikipedia.org/wiki/Linus_Torvalds'>Linus Torvalds</a></li>

## Küsimus

Kes arendas välja Linuxi tuuma?

## Vastus

Linus Torvalds

