# openSUSE

## Tunni sisu

<b>Ülevaade</b>
openSUSE Linux on loodud openSUSE Projekti poolt. See on kogukond, mis edendab Linuxi kasutamist kõikjal, töötades koos avatult, läbipaistvalt ja sõbralikul moel osana ülemaailmsest vaba ja avatud lähtekoodiga tarkvara kogukonnast. openSUSE on vanuselt teine tänaseni töötav Linuxi distributsioon. See jagab oma baassüsteemi SUSE auhindu võitnud SUSE Linux Enterprise toodetega.

<b>Paketihaldus</b>
Kasutab RPM paketihaldurit.

<b>Seadistatavus</b>
openSUSE on hea valik algajale linuxikasutajale. See pakub lihtsalt kasutatavat graafilist tarkvarahaldusrakendust (<a href="http://yast.github.io/">YaST</a>) ja baassüsteemi. openSUSE võimaldab kasutada Internetti muretsemata viiruste ja nuhkvara pärast. Saad nautida loomingulisust, tegeledes enda fotode, videote või koodiga.  

<b>Kasutusalad</b>
openSUSE Leap sobib kasutamiseks laua- ja sülearvutis.

## Harjutus

Kui sul on huvi kasutada openSUSE Linuxit enda operatsioonisüsteemina, mine vaata paigaldusjuhist ja proovi ära: <a href='https://software.opensuse.org/'>software.opensuse.org</a>

## Küsimus

Mis on openSUSE tarkvarahaldusvahendi nimi?

## Vastus

yast
