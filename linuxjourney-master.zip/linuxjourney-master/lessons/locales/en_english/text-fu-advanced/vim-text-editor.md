# Vim (Vi Improved)

## Lesson Content

Vim stands for vi (Improved) just like its name it stands for an improved version of the vi text editor command.

It's super lightweight, opening and editing a file with vim is quick and easy. It's also almost always available, if you booted up a random Linux distribution, chances are vim is installed by default. 

To fire up vim just type: <pre>vim</pre>

## Exercise

No exercises for this lesson.

## Quiz Question

No questions move along!

## Quiz Answer
