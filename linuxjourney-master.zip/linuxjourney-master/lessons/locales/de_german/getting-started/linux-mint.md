# Linux Mint

## Inhalt der Lektion

<b>Übersicht</b>
Linux Mint basiert auf Ubuntu. Es benutzt die Ubuntu Software-Quellen, dass heißt es stehen die gleichen Pakete wie für Ubuntu zur verfügung. Linux Mint wird von manchen Benutzern bevorzugt, da es ohne die proprietären Ubuntu Entwicklungen, wie etwa Unity ausgeliefert wird.

<b>Paketverwaltung</b>
Da Linux Mint auf Ubuntu basiert benutzt es ebenfalls den Debian Paketmanager.

<b>Eigenschaften</b>
Schöne Benutzeroberfläche, gut für Anfänger und weniger überfrachtet als Ubuntu. In diesem Kurs verwende ich Linux Mint, aber jede andere Distribution kann ebenfalls benutzt werden.

<b>Einsatz</b>
Gut für Desktops und Laptops.

## Übung

Wenn du dich für Linux Mint interessierst besuche am besten diese Website und probiere es aus: <a href='http://linuxmint.com/'>http://linuxmint.com/</a>

## Quizfrage

Worauf basiert Linux Mint?

## Quiz Antwort

Ubuntu
